In the WPS (WiFi Protected Setup) specification, it supports PIN and PBC for WPS/WSC connection.
In this document, it just describes the supporting principle on the WPS PBC topic.

Basically, there are two modes for WPS PBC (Push Button Configuration): Software PBC and Hardware PBC.
If the customer needs the WPS PBC functionality on the product, Realtek suggests using the following
priority order to implement the WPS PBC.

High Priority: Software PBC
Medium Priority: Hardware PBC on the SoC platform
Low Priority: Hardware PBC on the Wi-Fi dongle/module

About the software PBC, the wpa_supplicant and wpa_cli supports it by using the following command:
$> wpa_cli wps_pbc

If the customer needs to support the hardware PBC functionality, Realtek suggests to use the "Hardware PBC
on the SoC platform". The customer should create a hardware button for user to press and connect this
hardware button with a GPIO on the system. When the system detects the hardware button is pressed by detecting
the system GPIO, the system can launch the software PBC command to start the WPS PBC procedure.

If the GPIO resource is not available on the system, the only option to support the hardware PBC is "Hardware
PBC on the Wi-Fi dongle/module". However, the wpa_supplicant and wpa_cli are not able to detect the hardware
button because the detection rule doesn't be standardized. In order to support the hardware PBC, the
customer's utility must add some codes to know the hardware button on the Wi-Fi dongle/module is pressed or not.

The Realtek Wi-Fi Linux driver is able to detect the hardware button status. First of all, the customer has
to develop an application to capture the signal sent from Realtek Wi-Fi driver. In this package, we provide
a sample code named "signal_handle_ex.c" for developing this application. In the main function of this sample code,
it will pass its pid (process id) to Realtek Wi-Fi driver so that the driver will know the target process which
it wants to send the signal when the hardware button is pressed.

In the sample code, it registers a callback function named "HWPBC_SignalHandler" by using the signal system. When
the hardware button is pressed and the driver has detected it, the HWPBC_SignalHandler function will be called.
In the HWPBC_SignalHandler function, it should inform the wpa_supplicant to do the WPS procedure by using the
software PBC command described above.
===================================================================================================================
Note: The Realtek Wi-Fi driver will go to check the hardware button status per 2 seconds. So, we suggest the hardware
button should be pressed for at least 2 seconds to make sure the driver can detect this behavior.
